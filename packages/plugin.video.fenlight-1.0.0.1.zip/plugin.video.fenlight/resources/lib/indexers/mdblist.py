# -*- coding: utf-8 -*-
import sys
from threading import Thread
from indexers.movies import Movies
from indexers.tvshows import TVShows
from modules import kodi_utils
from modules.utils import paginate_list
from modules.settings import paginate, page_limit
from caches.lists_cache import lists_cache_object
from apis import mdblist_api

mdblist_search_lists = mdblist_api.mdblist_search_lists
get_icon = kodi_utils.get_icon
mdblist_icon, fanart = get_icon('mdblist'), kodi_utils.get_addon_fanart()
get_mdblist, get_mdblist_list_contents = mdblist_api.get_mdblist, mdblist_api.get_mdblist_list_contents
add_dir, external, sleep, set_property = kodi_utils.add_dir, kodi_utils.external, kodi_utils.sleep, kodi_utils.set_property
set_content, set_view_mode, end_directory = kodi_utils.set_content, kodi_utils.set_view_mode, kodi_utils.end_directory
make_listitem, build_url, add_items = kodi_utils.make_listitem, kodi_utils.build_url, kodi_utils.add_items
nextpage_landscape, set_category, home, folder_path = kodi_utils.nextpage_landscape, kodi_utils.set_category, kodi_utils.home, kodi_utils.folder_path


def search_mdblist_lists(params):
	def _builder():
		for item in data:
			try:
				item_count = item['items']
				if item_count == 0: continue
				list_name, user, slug = item['name'], item['user_name'], item['slug']
				list_name_upper = list_name.upper()
				if not slug: continue
				display = '%s | [I]%s (x%s)[/I]' % (list_name_upper, user, str(item_count))
				url = build_url({'mode': 'mdblist.build_mdblist_list', 'user': user, 'slug': slug, 'list_name': list_name})
				listitem = make_listitem()
				listitem.setLabel(display)
				listitem.setArt({'icon': mdblist_icon, 'poster': mdblist_icon, 'thumb': mdblist_icon, 'fanart': fanart, 'banner': fanart})
				info_tag = listitem.getVideoInfoTag()
				info_tag.setPlot(' ')
				yield (url, listitem, True)
			except: pass
	def _paginate_list(data, page_no, paginate_start):
		if use_result: 
			total_pages = 1
		elif paginate_enabled:
			limit = 50
			data, total_pages = paginate_list(data, page_no, limit, paginate_start)
			if is_home: 
				paginate_start = limit
		else: 
			total_pages = 1
		return data, total_pages, paginate_start

	handle, search_title = int(sys.argv[1]), ''
	try:
		is_home = home()
		mode, use_result, paginate_enabled = params.get('mode'), 'result' in params, paginate(is_home)
		page_no = int(params.get('new_page', 1))
		paginate_start = int(params.get('paginate_start', 0))
		search_title = params.get('key_id') or params.get('query')
		if use_result: lists = params.get('result', [])
		else: lists = mdblist_search_lists(search_title)
		lists = mdblist_search_lists(search_title)
		if not lists: return
		data, total_pages, paginate_start = _paginate_list(lists, page_no, paginate_start)
		add_items(handle, list(_builder()))
		if total_pages > page_no:
			new_page = str(page_no + 1)
			add_dir({'mode': mode, 'key_id': search_title, 'new_page': new_page, 'paginate_start': paginate_start}, 'Next Page (%s) >>' % new_page, handle, 'nextpage', nextpage_landscape)
	except: pass
	set_content(handle, 'files')
	set_category(handle, search_title.capitalize())
	end_directory(handle)
	set_view_mode('view.main')

def mdblist_list(params):
	def _process():
		for item in data:
			item_count = item['items']
			if item_count == 0: continue
			list_name, user, slug = item['name'], item.get('user_name', ''), item['slug']
			list_name_upper = list_name.upper()
			display = '%s | [I]%s (x%s)[/I]' % (list_name_upper, user, str(item_count))
			url = build_url({'mode': 'mdblist.build_mdblist_list', 'user': user, 'slug': slug, 'list_name': item['name'], 'list_id': item['id']})
			listitem = make_listitem()
			listitem.setLabel(display)
			listitem.setArt({'icon': mdblist_icon, 'poster': mdblist_icon, 'thumb': mdblist_icon, 'fanart': fanart, 'banner': fanart})
			info_tag = listitem.getVideoInfoTag()
			info_tag.setPlot(' ')
			yield (url, listitem, True)
	def _paginate_list(data, page_no, paginate_start):
		if use_result: 
			total_pages = 1
		elif paginate_enabled:
			limit = 50
			data, total_pages = paginate_list(data, page_no, limit, paginate_start)
			if is_home: 
				paginate_start = limit
		else: 
			total_pages = 1
		return data, total_pages, paginate_start

	string, page_no, paginate_start = params.get('string'), int(params.get('new_page', 1)), int(params.get('paginate_start', 0))
	handle = int(sys.argv[1])
	use_result = 'result' in params
	is_home = home()
	paginate_enabled = paginate(is_home)

	if use_result: results = params.get('result', [])
	else:
		results = lists_cache_object(get_mdblist, string, params)
	
	if not results: return

	data, total_pages, paginate_start = _paginate_list(results, page_no, paginate_start)

	add_items(handle, list(_process()))
	set_content(handle, 'files')
	set_category(handle, params.get('category_name', 'MDBList Lists'))
	if total_pages > page_no:
		new_page = str(int(page_no) + 1)
		add_dir({'mode': 'mdblist.mdblist_list', 'new_page': page_no + 1, 'string': string, 'path': params.get('path'), 'method': params.get('method'), 
		   'new_page': new_page, 'paginate_start': paginate_start}, 'Next Page (%s) >>' % new_page, handle, 'nextpage', nextpage_landscape)
	end_directory(handle)
	set_view_mode('view.main')
	
def get_trakt_top_100_lists(params):
	params = {'string': 'mdblist_top_100_lists', 'path': 'lists/top', 'method': 'get', 'category_name': params.get('category_name')}
	mdblist_list(params)

def get_my_list(params):
	params = {'string': 'mdblist_my_lists' , 'path': 'lists/user', 'method': 'get', 'category_name': params.get('category_name')}
	mdblist_list(params)
	
def build_mdblist_list(params):
	def _process(function, _list):
		if not _list['list']: return
		item_list_extend(function(_list).worker())
	def _paginate_list(data, page_no, paginate_start):
		if use_result: total_pages = 1
		elif paginate_enabled:
			limit = page_limit(is_home)
			data, total_pages = paginate_list(data, page_no, limit, paginate_start)
			if is_home: paginate_start = limit
		else: total_pages = 1
		return data, total_pages, paginate_start
	handle, is_external, is_home, content, list_name = int(sys.argv[1]), external(), home(), 'movies', params.get('list_name')
	try:
		threads, item_list = [], []
		item_list_extend = item_list.extend
		user, slug = '', ''
		paginate_enabled = paginate(is_home)
		use_result = 'result' in params
		page_no, paginate_start = int(params.get('new_page', 1)), int(params.get('paginate_start', 0))
		if page_no == 1 and not is_external: set_property('feren.exit_params', folder_path())
		if use_result: result = params.get('result', [])
		else:
			user, slug, list_id = params.get('user'), params.get('slug'), params.get('list_id')
			if user:
				result = get_mdblist_list_contents(user, slug)
			else:
				result = get_mdblist_list_contents(list_id=list_id)
		if not result: return
		process_list, total_pages, paginate_start = _paginate_list(result, page_no, paginate_start)
		all_movies = [i for i in process_list if i['mediatype'] == 'movie']
		all_tvshows = [i for i in process_list if i['mediatype'] == 'show']
		movie_list = {
			'list': [
				(
					(i.get('rank') - 1 if i.get('rank') else index),
					{
						'trakt': i.get('id'),
						'slug': f"{i.get('title', '').replace(' ', '-').lower()}-{i.get('release_year', '')}",
						'imdb': i.get('imdb_id'),
						'tmdb': i.get('id')
					}
				) for index, i in enumerate(all_movies)
			],
			'id_type': 'trakt_dict',
			'custom_order': 'true'
		}

		tvshow_list = {
			'list': [
				(
					(i.get('rank') - 1 if i.get('rank') else index),
					{
						'trakt': i.get('id'),
						'slug': f"{i.get('title', '').replace(' ', '-').lower()}-{i.get('release_year', '')}",
						'imdb': i.get('imdb_id'),
						'tmdb': i.get('id')
					}
				) for index, i in enumerate(all_tvshows)
			],
			'id_type': 'trakt_dict',
			'custom_order': 'true'
		}

		content = max([('movies', len(all_movies)), ('tvshows', len(all_tvshows))], key=lambda k: k[1])[0]
		for item in ((Movies, movie_list), (TVShows, tvshow_list)):
			threaded_object = Thread(target=_process, args=item)
			threaded_object.start()
			threads.append(threaded_object)
		[i.join() for i in threads]
		item_list.sort(key=lambda k: k[1])
		if use_result: return [i[0] for i in item_list]
		add_items(handle, [i[0] for i in item_list])
		if total_pages > page_no:
			new_page = str(page_no + 1)
			new_params = {'mode': 'mdblist.build_mdblist_list', 'list_name': list_name,
							'user': user, 'slug': slug, 'paginate_start': paginate_start, 'new_page': new_page,
							'list_id': params.get('list_id', '')}
			add_dir(new_params, 'Next Page (%s) >>' % new_page, handle, 'nextpage', nextpage_landscape)
	except: pass
	set_content(handle, content)
	set_category(handle, list_name)
	end_directory(handle, cacheToDisc=False if is_external else True)
	if not is_external:
		if params.get('refreshed') == 'true': sleep(1000)
		set_view_mode('view.%s' % content, content, is_external)