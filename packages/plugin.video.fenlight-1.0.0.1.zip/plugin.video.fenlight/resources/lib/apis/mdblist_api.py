import requests
from caches.main_cache import cache_object
from caches.lists_cache import lists_cache_object
from modules import kodi_utils
from caches.settings_cache import get_setting

logger = kodi_utils.logger

API_ENDPOINT = 'https://mdblist.com/api/%s'
LISTS_ENDPOINT = 'https://mdblist.com/%s'
timeout = 20

def call_mdblist(path='', data=None, method='get', list=False, search=False, search_title = None, pagination=False, page_no=None, limit=None):
    def send_query():
        resp = None
        try:
            if list:
                resp = requests.get(LISTS_ENDPOINT % path, headers=headers, timeout=timeout)
            elif method:
                if method == 'post':
                    resp = requests.post(API_ENDPOINT % path , headers=headers, timeout=timeout)
                elif method == 'delete':
                    resp = requests.delete(API_ENDPOINT % path, headers=headers, timeout=timeout)
                elif method == 'get':
                    resp = requests.get(API_ENDPOINT % path, headers=headers, timeout=timeout)
            resp.raise_for_status()
        except Exception as e: return logger('MDBList Error', str(e))
        return resp
    headers = {'Content-Type': 'application/json'}
    if list:
        path += '/json'
    else:
        if search:
            path += 'lists/search?s=' + search_title
            path += '&'
        else:
            path += '?'
        mdblist_api = get_setting('feren.mdblist_api', None)
        if not mdblist_api: return None
        path += 'apikey=%s' % mdblist_api
    if pagination:
        path += '&' if search or list else '?'
        path += f'limit={limit}&offset={(limit * (page_no - 1))}'
    response = send_query()
    try: 
        status_code = response.status_code
    except: 
        return None
    response.encoding = 'utf-8'
    try: result = response.json()
    except: return None
    return result

def get_mdblist(params):
    result = call_mdblist(params['path'], method=params.get('method'), list=params.get('list'))
    return result

def get_mdblist_list_contents(user=None, slug=None, list_id=None):
    if user and slug:
        string = 'mdblist_%s_list' % (user + slug)
        params = {'path': 'lists/%s/%s' % (user, slug), 'method': 'get', 'list': True}
        return lists_cache_object(get_mdblist, string, params)
    else:
        string = 'mdblist_%s_list' % (list_id)
        params = {'path': 'lists/%s/items' % (list_id), 'method': 'get', 'list': False}
        return lists_cache_object(get_mdblist, string, params)

def mdblist_search_lists(search_title):
    def _process(dummy_arg):
        return call_mdblist(search=True, search_title=search_title)
    string = 'mdblist_search_lists_%s' % (search_title)
    return cache_object(_process, string, 'dummy_arg', False, 4)